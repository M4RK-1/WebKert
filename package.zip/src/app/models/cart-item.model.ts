// src/app/models/cart-item.model.ts
export interface CartItem {
  productId: string;
  quantity: number;
}
