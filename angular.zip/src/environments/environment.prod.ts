// src/environments/environment.prod.ts

export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAYxl6OIkx3j2HDmFmLijBpH50koFhiChE",
    authDomain: "vizimarkproject.firebaseapp.com",
    projectId: "vizimarkproject",
    storageBucket: "vizimarkproject.appspot.com",
    messagingSenderId: "71546811151",
    appId: "1:71546811151:web:1a22421822da30ee70047a"
  }
};
