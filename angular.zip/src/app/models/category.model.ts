// src/app/models/category.model.ts

export interface Category {
  id: string;
  name: string;
}
